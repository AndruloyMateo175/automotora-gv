// ============================================================
// EXTRACTOR DE MODELOS - Pegar en consola del browser
// Ejecutar desde la pestaña principal de eFactura (MenuPrincipal)
// ============================================================

(async function() {

  // ---- PASO 1: Encontrar el iframe correcto ----
  let targetFrame = null;
  for (let i = 0; i < window.frames.length; i++) {
    try {
      if (window.frames[i].location.href.includes('ListadoFacturasCompra')) {
        targetFrame = window.frames[i];
        break;
      }
    } catch(e) {}
  }
  if (!targetFrame) { alert('ERROR: No se encontró el iframe ListadoFacturasCompra. Abrí Facturas de Compra primero.'); return; }

  const doc = targetFrame.document;

  // ---- PASO 2: Obtener csrf_token fresco ----
  const csrf = doc.querySelector('input[name="csrf_token"]')?.value;
  if (!csrf) { alert('ERROR: No se encontró csrf_token'); return; }
  console.log('✅ csrf_token encontrado:', csrf.substring(0,15)+'...');

  // ---- PASO 3: Función para hacer POST y obtener PDF binario ----
  async function fetchPDF(sessId, hash) {
    const fd = new targetFrame.FormData();
    fd.append('nmgp_chave', '');
    fd.append('nmgp_opcao', '');
    fd.append('nmgp_orden', '');
    fd.append('SC_lig_apl_orig', 'ListadoFacturasCompra');
    fd.append('nmgp_parm_acum', '');
    fd.append('nmgp_quant_linhas', '');
    fd.append('nmgp_url_saida', '/online/ListadoFacturasCompra/');
    fd.append('nmgp_parms', `@SC_par@${sessId}@SC_par@ListadoFacturasCompra@SC_par@${hash}`);
    fd.append('nmgp_tipo_pdf', '');
    fd.append('nmgp_outra_jan', 'false');
    fd.append('nmgp_orig_pesq', '');
    fd.append('SC_module_export', '');
    fd.append('script_case_init', sessId);
    fd.append('nm_grid_submit', '1');
    fd.append('csrf_token', csrf);

    const resp = await targetFrame.fetch('https://sc.220efactura.info/online/compras_open_link/', {
      method: 'POST',
      credentials: 'include',
      body: fd
    });
    const ct = resp.headers.get('content-type') || '';
    console.log(`  → status=${resp.status} content-type=${ct}`);
    
    if (ct.includes('pdf')) {
      // Es PDF binario - convertir a base64
      const buf = await resp.arrayBuffer();
      const bytes = new Uint8Array(buf);
      let bin = '';
      for (let i = 0; i < bytes.byteLength; i++) bin += String.fromCharCode(bytes[i]);
      return { type: 'pdf', data: btoa(bin), size: bytes.byteLength };
    } else {
      // Puede ser HTML con redirect o texto
      const text = await resp.text();
      // Buscar URL del PDF en la respuesta HTML
      const urlMatch = text.match(/imprimirfacturas\.php[^"']+/);
      return { type: 'html', text: text.substring(0, 1000), pdfUrl: urlMatch?.[0] };
    }
  }

  // ---- PASO 4: Función para extraer texto de PDF base64 usando pdf.js ----
  async function extractTextFromPDF(base64) {
    // Cargar pdf.js si no está cargado
    if (!targetFrame.pdfjsLib) {
      await new Promise((resolve, reject) => {
        const script = targetFrame.document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
        script.onload = resolve;
        script.onerror = reject;
        targetFrame.document.head.appendChild(script);
      });
      targetFrame.pdfjsLib.GlobalWorkerOptions.workerSrc = 
        'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
    }

    const bin = atob(base64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    
    const pdf = await targetFrame.pdfjsLib.getDocument({ data: arr }).promise;
    let fullText = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      fullText += content.items.map(item => item.str).join(' ') + '\n';
    }
    return fullText;
  }

  // ---- PASO 5: Parsear modelo/chasis/motor del texto ----
  function parsearFactura(text) {
    const t = text.toUpperCase();
    
    // Modelos BMW/MINI/VOLVO conocidos
    const modeloPatterns = [
      /BMW\s+(X\d|M\d|\d+)\s*[A-Z0-9]+[^,\n]*/,
      /MINI\s+(COOPER|CLUBMAN|COUNTRYMAN|PACEMAN|ROADSTER|CABRIO)[^,\n]*/,
      /VOLVO\s+(XC\d+|S\d+|V\d+|C\d+)[^,\n]*/,
      /MOTORRAD\s+[A-Z0-9\s]+/,
    ];
    
    let modelo = null;
    for (const pat of modeloPatterns) {
      const m = t.match(pat);
      if (m) { modelo = m[0].trim().substring(0, 50); break; }
    }

    // Chasis: VIN 17 caracteres
    const vinMatch = t.match(/\b[A-HJ-NPR-Z0-9]{17}\b/);
    const chasis = vinMatch ? vinMatch[0] : null;

    // Motor: típicamente alfanumérico después de "MOTOR" o "N°" o "NRO"
    const motorMatch = t.match(/(?:MOTOR|N[°ORo]+\.?\s*MOTOR)[:\s#]*([A-Z0-9]{6,20})/);
    const motor = motorMatch ? motorMatch[1] : null;

    // Año: 4 dígitos entre 2010-2030
    const anioMatch = t.match(/\b(20[12][0-9])\b/);
    const anio = anioMatch ? anioMatch[1] : null;

    return { modelo, chasis, motor, anio };
  }

  // ---- PASO 6: Recolectar todas las lupas de la página actual ----
  function getLupasVehiculos() {
    const lupas = Array.from(doc.querySelectorAll('a[id*="verlupa"]'));
    const result = [];
    for (const link of lupas) {
      const href = link.getAttribute('href') || '';
      const match = href.match(/@SC_par@(\d+)@SC_par@ListadoFacturasCompra@SC_par@([a-f0-9]+)/);
      if (!match) continue;
      const sessId = match[1];
      const hash = match[2];
      const row = link.closest('tr');
      const cells = row ? Array.from(row.querySelectorAll('td')).map(td => td.textContent.trim()) : [];
      // Columna moneda y monto (aprox col 8 y 9)
      const moneda = cells[8] || '';
      const monto = parseFloat((cells[9] || '0').replace(/\./g, '').replace(',', '.'));
      // Solo vehículos: USD > 5000
      if (moneda === 'USD' && monto > 5000) {
        result.push({ sessId, hash, moneda, monto, cells });
      }
    }
    return result;
  }

  // ---- PASO 7: Ejecutar en todas las páginas ----
  const allResults = [];
  let pageNum = 1;

  // Cambiar a 50 filas por página para ir más rápido
  // (si hay un selector de cantidad de filas)
  const rowSelector = doc.querySelector('select[name*="quant_linhas"], select[name*="linhas"]');
  if (rowSelector) {
    rowSelector.value = '50';
    rowSelector.dispatchEvent(new Event('change'));
    await new Promise(r => setTimeout(r, 2000));
  }

  while (true) {
    console.log(`\n📄 Procesando página ${pageNum}...`);
    const lupas = getLupasVehiculos();
    console.log(`  Encontradas ${lupas.length} facturas de vehículos`);

    for (let i = 0; i < lupas.length; i++) {
      const { sessId, hash, monto } = lupas[i];
      console.log(`  [${i+1}/${lupas.length}] hash=${hash.substring(0,8)}... monto=USD ${monto}`);
      
      try {
        const result = await fetchPDF(sessId, hash);
        
        if (result.type === 'pdf') {
          console.log(`    PDF ok (${result.size} bytes), extrayendo texto...`);
          const text = await extractTextFromPDF(result.data);
          const parsed = parsearFactura(text);
          console.log(`    → modelo=${parsed.modelo} chasis=${parsed.chasis} motor=${parsed.motor}`);
          allResults.push({ hash, monto, ...parsed, raw: text.substring(0, 500) });
        } else {
          console.log(`    Respuesta HTML, pdfUrl=${result.pdfUrl}`);
          // Si tenemos URL del PDF, intentar GET directo
          if (result.pdfUrl) {
            const r2 = await targetFrame.fetch('https://sc.220efactura.info/scriptsefa/' + result.pdfUrl, { credentials: 'include' });
            const buf = await r2.arrayBuffer();
            const bytes = new Uint8Array(buf);
            let bin = ''; for(let j=0;j<bytes.byteLength;j++) bin += String.fromCharCode(bytes[j]);
            const text = await extractTextFromPDF(btoa(bin));
            const parsed = parsearFactura(text);
            allResults.push({ hash, monto, ...parsed });
          } else {
            allResults.push({ hash, monto, error: 'no_pdf', htmlSnippet: result.text.substring(0,200) });
          }
        }
      } catch(err) {
        console.error(`    ERROR: ${err.message}`);
        allResults.push({ hash, monto, error: err.message });
      }

      // Pausa entre requests para no sobrecargar el servidor
      await new Promise(r => setTimeout(r, 800));
    }

    // Intentar ir a la siguiente página
    const nextBtn = Array.from(doc.querySelectorAll('a, button')).find(el => 
      el.textContent.trim() === '>' || el.getAttribute('title')?.includes('siguiente') ||
      el.id?.includes('next') || el.className?.includes('next')
    );
    if (!nextBtn || nextBtn.disabled) {
      console.log('\n✅ Última página alcanzada.');
      break;
    }
    nextBtn.click();
    pageNum++;
    await new Promise(r => setTimeout(r, 2500));
  }

  // ---- PASO 8: Descargar resultado como JSON ----
  console.log(`\n📊 Total resultados: ${allResults.length}`);
  const json = JSON.stringify(allResults, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'modelos_extraidos.json';
  a.click();
  console.log('✅ Descargado modelos_extraidos.json');
  
  // También disponible en window
  window._modelosExtraidos = allResults;
  return allResults;

})();
